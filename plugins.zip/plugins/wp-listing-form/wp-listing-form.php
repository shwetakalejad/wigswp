<?php
/* sp-form-example/sp-form-example.php
Plugin Name: Business Listing Form Plugin
Plugin URI: business-listing-plugin
Description: Simple Business Listing Form Plugin Form
Version: 1.0
Author: Shweta Kale
Author URI:
*/
	function html_form_code() {
		?>
    <form action="<?php esc_url( $_SERVER['REQUEST_URI'] );?>" method="post">
    <p>
	Your Name (required) <br />
    <input type="text" name="cf-name" pattern="[a-zA-Z0-9 ]+" value="<?php ( isset( $_POST["cf-name"] ) ? esc_attr( $_POST["cf-name"] ) : '' ); ?>" size="40" />
    </p>
    <p>
    Your Email (required) <br />
    <input type="email" name="cf-email" value= "<?php ( isset( $_POST["cf-email"] ) ? esc_attr( $_POST["cf-email"] ) : '' ); ?>" size="40" />
    </p>
   <p>
    Business Name(required) <br />
    <input type="text" name="cf-business-name" pattern="[a-zA-Z0-9 ]+" value= "<?php ( isset( $_POST["cf-business-name"] ) ? esc_attr( $_POST["cf-business-name"] ) : '' ); ?>" size="40" />
    </p>
	   <p>
    Business Address(required) <br />
    <input type="text" name="cf-business-address" pattern="[a-zA-Z0-9 ]+" value= "<?php ( isset( $_POST["cf-business-address"] ) ? esc_attr( $_POST["cf-business-address"] ) : '' ); ?>" size="40" />
    </p>
	
	<p>
    Business Phone (required) <br />
    <input type="text" name="cf-business-phone" pattern="[a-zA-Z0-9 ]+" value= "<?php ( isset( $_POST["cf-business-phone"] ) ? esc_attr( $_POST["cf-business-phone"] ) : '' ); ?>" size="40" />
    </p>
	<p>
	 Business Category (required) <br />
	
		<?php wp_dropdown_categories( 'hide_empty=0'); ?>
	
</p>
	<input type="hidden" name="post_type" id="post_type" value="my_custom_posttype" />
    <p><input type="submit" name="cf-submitted" value="Send"/></p>
	<?php wp_nonce_field( 'cpt_nonce_action', 'cpt_nonce_field' ); ?>
    </form>
	
	<?php
}

function create_business_listing() {

    // if the submit button is clicked, send the email
    if ( isset( $_POST['cf-submitted'] ) ) {

        // sanitize form values
       $name    = sanitize_text_field( $_POST["cf-name"] );
       $email   = sanitize_email( $_POST["cf-email"] );
	   $business_name    = sanitize_text_field( $_POST["cf-business-name"] );
       $business_address   = sanitize_text_field( $_POST["cf-business-address"] );
	   $business_phone   = sanitize_text_field( $_POST["cf-business-phone"] );
	    $business_cat   = $_POST["cat"];
   

$user_id = register_businesslisting_user($email);
if($user_id == 0){
	echo "email exists"; exit;
}
//if (isset( $_POST['cpt_nonce_field'] )  ) {
// create post object with the form values
$my_cptpost_args = array(

'post_title' => "business_listing ". $name,

'post_status'   => 'pending',

'post_author'   => $user_id,

'post_type' => 'business_listing'


);

// insert the post into the database
$cpt_id = wp_insert_post( $my_cptpost_args, $wp_error);
update_post_meta($cpt_id,'customername',$name);
update_post_meta($cpt_id,'customeremail_address',$email);
update_post_meta($cpt_id,'business_name',$business_name);
update_post_meta($cpt_id,'business_address',$business_address);
update_post_meta($cpt_id,'business_phone',$business_phone);
update_post_meta($cpt_id,'business_category',$business_cat);

//}

	}
}


function register_businesslisting_user($email_address){
	
	
if( null == username_exists( $email_address ) ) {

  // Generate the password and create the user
  //echo $password = wp_generate_password( 12, false );
  $password ="admin@123";
  $user_id = wp_create_user( $email_address, $password, $email_address );

  // Set the nickname
  wp_update_user(
    array(
      'ID'          =>    $user_id,
      'nickname'    =>    $email_address
    )
  );

  // Set the role
  $user = new WP_User( $user_id );
  $user->set_role( 'subscriber' );
//die();
  // Email the user
  //wp_mail( $email_address, 'Welcome!', 'Your Password: ' . $password );

  return $user_id;
} // end if
	return 0;
	
}
function deliver_mail() {
    // if the submit button is clicked, send the email
    if ( isset( $_POST['cf-submitted'] ) ) {
//echo "<pre>";
	//print_r($_POST);
	//echo $_POST["cat"] ;
	
        // sanitize form values
       echo  $name    = sanitize_text_field( $_POST["cf-name"] );
       echo   $email   = sanitize_email( $_POST["cf-email"] );
	    echo  $business_name    = sanitize_text_field( $_POST["cf-business-name"] );
       echo   $business_address   = sanitize_text_field( $_POST["cf-business-address"] );
	   echo   $business_cat   = get_cat_name($_POST["cat"]);
       echo   $subject = sanitize_text_field( $_POST["cf-subject"] );
       echo   $message = esc_textarea( $_POST["cf-message"] );
die();
        // get the blog administrator's email address
        $to = get_option( 'admin_email' );

        $headers = "From: $name <$email>" . "\r\n";

        // If email has been process for sending, display a success message
      /*  if ( wp_mail( $to, $subject, $message, $headers ) ) {
            echo '<div>';
            echo ' <p>Thanks for contacting me, expect a response soon.</p>';
            echo '</div>';
        } else {
           echo ' An unexpected error occurred';
        }
		*/
    }
}

function cf_shortcode() {
    ob_start();
	create_business_listing();
    //deliver_mail();
    html_form_code();

    return ob_get_clean();
}

add_shortcode( 'sitepoint_contact_form', 'cf_shortcode' );
?>